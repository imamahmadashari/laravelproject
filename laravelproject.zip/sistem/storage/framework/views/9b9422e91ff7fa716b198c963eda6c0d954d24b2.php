<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<div class="table-responsive">
    <table id="datatables" class="table table-striped table-hover table-bordered">
        <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">ID Transaksi</th>
                <th class="text-center">Kode Barang</th>
                <th class="text-center">Total Harga</th>
                <th class="text-center">Laba</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->id); ?></td>
                <td><?php echo e($value->id_transaksi); ?></td>
                <td><?php echo e($value->kode); ?></td>
                <td><?php echo e($value->total_harga); ?></td>
                <td><?php echo e($value->laba); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\laravelproject\sistem\resources\views/penjualan-pdf.blade.php ENDPATH**/ ?>