<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Mahasiswa</div>
                <div class="card-body">
                    <h5>Tambah Data Mahasiswa</h5><hr>
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('simpan-data-mahasiswa')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="form-group row">
                                    <label for="nim" class="col-md-4 col-form-label text-md-right">NIM*</label>

                                    <div class="col-md-8">
                                        <input id="nim" type="number" class="form-control <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nim" value="<?php echo e(old('nim')); ?>" required autofocus>

                                        <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="nama" class="col-md-4 col-form-label text-md-right">Nama*</label>

                                    <div class="col-md-8">
                                        <input id="nama" type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e(old('nama')); ?>">

                                        <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="foto" class="col-md-4 col-form-label text-md-right">Foto*</label>

                                    <div class="col-md-8">
                                        <input type="file" onchange="readFoto(event)" class="form-control" name="foto" value="<?php echo e(old('foto')); ?>">

                                        <img id='output' style="width: 100px;">

                                        <?php if ($errors->has('foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('foto'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="form-group row">
                                    <label for="tanggal_lahir" class="col-md-4 col-form-label text-md-right">Tanggal Lahir*</label>

                                    <div class="col-md-8">
                                        <input id="tanggal_lahir" type="date" class="form-control <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required>

                                        <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="program_studi" class="col-md-4 col-form-label text-md-right">Program Studi*</label>

                                    <div class="col-md-8">
                                        <input id="program_studi" type="text" class="form-control <?php if ($errors->has('program_studi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('program_studi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="program_studi" value="<?php echo e(old('program_studi')); ?>" required>

                                        <?php if ($errors->has('program_studi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('program_studi'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="dokumen" class="col-md-4 col-form-label text-md-right">Dokumen*</label>

                                    <div class="col-md-8">
                                        <input type="file" class="form-control" name="dokumen" value="<?php echo e(old('dokumen')); ?>">

                                        <?php if ($errors->has('dokumen')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dokumen'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="program_studi" class="col-md-4 col-form-label text-md-right"></label>

                                    <div class="col-md-8">
                                        <button class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <form method="POST" action="<?php echo e(url('hapus-mahasiswa-checklist/{id}')); ?>">
                        <?php echo csrf_field(); ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center"><input type="checkbox" name="hapus_data" class="checkbox" id="hapus_data" value=""></th>
                                    <th class="text-center">No</th>
                                    <th class="text-center" width="10%">Foto</th>
                                    <th class="text-center">NIM</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center">Tanggal Lahir</th>
                                    <th class="text-center">Program Studi</th>
                                    <th class="text-center">Dokumen</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align="center"><input type="checkbox" name="nim_hapus[]" class="checkbox-inline" value="<?php echo e($value->nim); ?>"></td>
                                    <td align="center"><?php echo e($no+1); ?></td>
                                    <td align="center">
                                        <img src="images/foto/<?php echo e($value->foto); ?>" width="100%">
                                    </td>
                                    <td align="center"><?php echo e($value->nim); ?></td>
                                    <td><?php echo e($value->nama); ?></td>
                                    <td align="center"><?php echo e($value->tanggal_lahir); ?></td>
                                    <td align="center"><?php echo e($value->program_studi); ?></td>
                                    <td align="center">
                                        <a href="dokumen/<?php echo e($value->dokumen); ?>"><button class="btn btn-success" type="button">Download</button></a>
                                    </td>
                                    <td align="center">
                                        <a href="<?php echo e(url($value->nim.'/edit-mahasiswa')); ?>">
                                        <button class="btn btn-primary">Ubah</button>
                                        </a>
                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ModalUbah<?php echo e($value->nim); ?>">Modal Ubah</button>
                                        <a href="<?php echo e(url($value->nim.'/hapus-mahasiswa')); ?>">
                                        <button type="button" class="btn btn-danger">Hapus</button>
                                        </a>
                                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#ModalHapus<?php echo e($value->nim); ?>">Modal Hapus</button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <input type="submit" class="btn btn-danger" name="hapus_data" value="Hapus Data yang di tandai">
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="ModalUbah<?php echo e($value->nim); ?>" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Edit Data Mahasiswa</h4>
        </div>
        <div class="modal-body">
                                <form method="POST" action="<?php echo e(url('update-mahasiswa/'.$value->nim)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="form-group row">
                                    <label for="nim" class="col-md-4 col-form-label text-md-right">NIM*</label>

                                    <div class="col-md-8">
                                        <input id="nim" type="number" class="form-control <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nim" value="<?php echo e($value->nim); ?>" required autofocus>

                                        <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="nama" class="col-md-4 col-form-label text-md-right">Nama*</label>

                                    <div class="col-md-8">
                                        <input id="nama" type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e($value->nama); ?>">

                                        <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="form-group row">
                                    <label for="tanggal_lahir" class="col-md-4 col-form-label text-md-right">Tanggal Lahir*</label>

                                    <div class="col-md-8">
                                        <input id="tanggal_lahir" type="date" class="form-control <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="tanggal_lahir" value="<?php echo e($value->tanggal_lahir); ?>" required>

                                        <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="program_studi" class="col-md-4 col-form-label text-md-right">Program Studi*</label>

                                    <div class="col-md-8">
                                        <input id="program_studi" type="text" class="form-control <?php if ($errors->has('program_studi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('program_studi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="program_studi" value="<?php echo e($value->program_studi); ?>" required>

                                        <?php if ($errors->has('program_studi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('program_studi'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="program_studi" class="col-md-4 col-form-label text-md-right"></label>

                                    <div class="col-md-8">
                                        <button class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- Modal -->
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="ModalHapus<?php echo e($value->nim); ?>" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Hapus Data Mahasiswa</h4>
        </div>
        <div class="modal-body">
            Apakah anda yakin akan menghapus data <strong><?php echo e($value->nama); ?></strong> ? <br>
            <a href="<?php echo e(url($value->nim.'/hapus-mahasiswa')); ?>">
            <button class="btn btn-danger">Hapus</button>
            </a>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script type="text/javascript">
    var readFoto= function(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
      var dataURL = reader.result;
      var output = document.getElementById('output');
      output.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
  };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelproject\sistem\resources\views/mahasiswa.blade.php ENDPATH**/ ?>