<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Mahasiswa</div>

                <div class="card-body">
                    <table class="table-resposive table table-hover table-striped">
                        <thead>
                            <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">NIM</th>
                            <th class="text-center">Nama</th>
                            <th class="text-center">Tanggal Lahir</th>
                            <th class="text-center">Program Studi</th>
                            <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td align="center"><?php echo e($no+1); ?></td>
                                <td align="center"><?php echo e($value->nim); ?></td>
                                <td align="center"><?php echo e($value->nama); ?></td>
                                <td align="center"><?php echo e($value->tanggal_lahir); ?></td>
                                <td align="center"><?php echo e($value->program_studi); ?></td>
                                <td align="center">
                                    <button class="btn btn-primary">Ubah</button>
                                    <button class="btn btn-danger">Hapus</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelproject\sistem\resources\views/mahasiswa-coba.blade.php ENDPATH**/ ?>