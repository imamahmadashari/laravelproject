<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Mahasiswa</div>
                <div class="card-body">
                    <h5>Tambah Data Mahasiswa</h5><hr>
                    <form method="POST" action="<?php echo e(url('update-mahasiswa/'.$data->nim)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="form-group row">
                                    <label for="nim" class="col-md-4 col-form-label text-md-right">NIM*</label>

                                    <div class="col-md-8">
                                        <input id="nim" type="number" class="form-control <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nim" value="<?php echo e($data->nim); ?>" required autofocus>

                                        <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="nama" class="col-md-4 col-form-label text-md-right">Nama*</label>

                                    <div class="col-md-8">
                                        <input id="nama" type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nama" value="<?php echo e($data->nama); ?>">

                                        <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="form-group row">
                                    <label for="tanggal_lahir" class="col-md-4 col-form-label text-md-right">Tanggal Lahir*</label>

                                    <div class="col-md-8">
                                        <input id="tanggal_lahir" type="date" class="form-control <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="tanggal_lahir" value="<?php echo e($data->tanggal_lahir); ?>" required>

                                        <?php if ($errors->has('tanggal_lahir')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('tanggal_lahir'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="program_studi" class="col-md-4 col-form-label text-md-right">Program Studi*</label>

                                    <div class="col-md-8">
                                        <input id="program_studi" type="text" class="form-control <?php if ($errors->has('program_studi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('program_studi'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="program_studi" value="<?php echo e($data->program_studi); ?>" required>

                                        <?php if ($errors->has('program_studi')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('program_studi'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="program_studi" class="col-md-4 col-form-label text-md-right"></label>

                                    <div class="col-md-8">
                                        <button class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelproject\sistem\resources\views/mahasiswa-edit.blade.php ENDPATH**/ ?>